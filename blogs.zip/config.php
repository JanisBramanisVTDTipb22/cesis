<?php

return [
    "host" => "localhost",
    "dbname" => "blog_janis_bramanis",
    "user" => "root",
    "password" => "",
    "charset" => "utf8mb4"
];